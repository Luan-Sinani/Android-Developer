# Popular Movies 1
Popular Movies (Stage 1) App is the first project for Udacity's Android Developer Nanodegree program.
## Used libraries
- Butter Knife
- Picasso
## How to use
You are going to need an API Key to use this app. To get an API Key, Go to www.themoviedb.org and sign up. 
Edit the Utilities/NetworkUtiles.java file. There is an **apiKey** variable. Replace the string with your own api key. 

<img src="https://user-images.githubusercontent.com/23320682/41442227-ccc1df12-703e-11e8-945f-c051e1c8c593.png" width="300">
<img src="https://user-images.githubusercontent.com/23320682/41442228-cdfeff22-703e-11e8-8629-b1cac6f0cd3b.png" width="300">

